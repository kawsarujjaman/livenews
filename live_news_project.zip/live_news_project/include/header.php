<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live News Project using: BOOTSTRAP CSS PHP JAVA</title>
    <!-- Style sheet link -->
    <link rel="stylesheet" href="include/style.css" type="text/css">
    <!-- Fontawesome link -->
    <script src="https://kit.fontawesome.com/71f2e6313b.js" crossorigin="anonymous"></script>
    <!-- Bootstrap cdn link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


</head>
<body>

 <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="index.php"> <img src="images/logo.png" alt="Logo"> </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin/index">Login</a>
                    </li>
                    
                </ul>
        </div>

        
        </nav>
        <div class="secondary_menu text-light bg-dark text-center">
<?php
require_once "include/config.php";

    if(isset($_GET["category_ID"])){
        $category_id = $_GET["category_ID"];
    }


        $catQuery= "SELECT * FROM category WHERE post>0";
        $runCat_query= mysqli_query($connection, $catQuery) or die("Category query failed.");
        if(mysqli_num_rows($runCat_query)){
            $active ='';
        
        ?>
            <ul>
            <?php
            while($getRow= mysqli_fetch_assoc($runCat_query)){

                if(isset($_GET["category_ID"])){
                    $category_id = $_GET["category_ID"];
                

                if($getRow['category_id'] == $category_id){
                    $active= 'active';
                }else{
                    $active= '';
                }
            }
                echo "<li  class='$active'> <a  href='category.php?category_ID={$getRow['category_id']}'>{$getRow['category_name']}</a> </li>";
            }
            ?>
                
            </ul>
            
        <?php }?>



        
        </div>
</div>
  




