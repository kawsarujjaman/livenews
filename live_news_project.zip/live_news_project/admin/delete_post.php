<?php
include_once "include/config.php";

// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}



$post_id= $_GET["id"];
$cat_id= $_GET["catId"];

$deleteImg= "SELECT * FROM post WHERE post_id= $post_id";
$runImgQuery= mysqli_query($connection, $deleteImg) or die("Image delete query failed.");
$getRow= mysqli_fetch_assoc($runImgQuery);

unlink("uploads/".$getRow['post_img']);

$deletePost_query="DELETE FROM post WHERE post_id= '$post_id';";
$deletePost_query.="UPDATE category SET category.post= category.post - 1 WHERE category.category_id= {$cat_id}";
$runDelete_query= mysqli_multi_query($connection, $deletePost_query) or die("Delete Query failed.");

 if($runDelete_query){
    header ("location:post.php?deleted");

 }else{
     header ("location:post.php?deletedFail");

 }
?>