<?php 
include "include/config.php";
// Shows error for week. after change ($_FILES["new_img"]["tmp_name"]) it fixed
if(empty($_FILES["new_img"]["tmp_name"])){
    $new_name= $_POST["old_img"];
   }else{
    $errors= array();

   
    $imgFile= $_FILES["new_img"];
    $img_name= $imgFile["name"];
    $img_size= $imgFile["size"];
    $img_tmp=  $imgFile["tmp_name"];
    $img_type= $imgFile["type"];

    // end(explode('.',$img_name)) show error Than write @end(explode)
    $file_ext= @end(explode('.',$img_name));
    $extentions= array("jpeg","JPEG", "jpg", "JPG", "png", "PNG");

    if(in_array($file_ext, $extentions)==false){
        $errors[]="<font color='red'> This extension file not allowed, please choose JPEG, JPG, PNG file.</font>";
    }
    if($img_size > 2097152){
        $errors[]="<font color='red'>File size must be 2 MB or Lower. </font> "; 
    }

    $new_imgName= time()."-".basename($img_name);
    $target= "uploads/".$new_imgName;
    


 if(empty($errors) === true){
        move_uploaded_file($img_tmp, $target);
    }else{
        print_r($errors);
        die();
    }
}

$title= $_POST["post_title"]; 
$description= $_POST["post_desc"];
$category= $_POST["post_cate"];
$id= $_POST["post_id"];
$old_categoty = $_POST["old_categoty"];

$updatQuery= "UPDATE post SET title= '{$title}', description= '{$description}', category= '{$category}', post_img= '{$new_imgName}' WHERE post_id= '{$id}';";

 
 
 if($_POST["old_categoty"] != $_POST["post_cate"]){
     $updatQuery.="UPDATE category SET category.post= category.post - 1 WHERE category.category_id= {$_POST['old_categoty']};";
     $updatQuery.="UPDATE category SET category.post= category.post + 1 WHERE category.category_id= {$_POST['post_cate']}";

 }

 $runUpdate_query= mysqli_multi_query($connection, $updatQuery) or die("Update query failed.....");

 if($runUpdate_query){
   header("location:post.php?updated");
 }else{
    echo "Data Update Failed. ";

 }

?>