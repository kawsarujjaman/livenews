<?php 
require_once "include/config.php";
include_once "include/header.php";

// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}


if($_SESSION["user_role"] == '0'){
    header ("location: post.php");
}
?>


<?php
if(isset($_POST["submit"])){
    $db_id= mysqli_real_escape_string($connection, $_POST["id"]);
    $fname= mysqli_real_escape_string($connection, $_POST["fname"]);
    $lname= mysqli_real_escape_string($connection, $_POST["lname"]);
    $user_name= mysqli_real_escape_string($connection, $_POST["user_name"]);
    $role= mysqli_real_escape_string($connection, $_POST["role"]);
// UPDATE `users` SET `last_name` = 'badiur Alam', `user_name` = 'alam', `user_email` = 'alam@gmail.com', `role` = '0' WHERE `users`.`id` = 8;
    $updtQuery= "UPDATE users SET first_name= '{$fname}', last_name= '{$lname}', user_name= '{$user_name}', role= '{$role}' WHERE id= '{$db_id}'";
    $runUpdtQuery= mysqli_query($connection, $updtQuery) or die("Query Failed. ");

    if($runUpdtQuery==true){
        header("location: users.php?updated");
      
    }else{
        echo "Data update failed";
    }
}

?>


<div class="container">
<div class="admin-content">
    <div class="row">
        <div class="col-md-12">
            <h1 class=" admin-heading"> Add Users</h1>

        </div>

        <div class="col-md-offset-3 col-md-6 m-auto bg-light">


        <!-- Form starts here -->
     
        <?php 
            $id= $_GET['id'];
            $selectQuery= "SELECT * FROM users WHERE id= '$id' ";
            $runSelectQuery= mysqli_query($connection, $selectQuery);
            $counT= mysqli_num_rows($runSelectQuery) or die("Query Failed. ");
            if($counT>0){
                while($getRow= mysqli_fetch_assoc($runSelectQuery)){

                
        ?>
            <form action="<?php $_SERVER['PHP_SELF'];?> " method="post" >
                <input type="hidden" name="id" value="<?php echo  $getRow['id']; ?>" >
                 <div class="form-group">
                    <label for="fname"> First Name</label>
                    <input type="text" name="fname" class="form-control" value="<?php echo  $getRow['first_name']; ?>" >                
                </div>
                <div class="form-group">
                    <label for="lname"> Last Name</label>
                    <input type="text" name="lname" class="form-control" value="<?php echo  $getRow['last_name']; ?>" >                
                </div>
                <div class="form-group">
                    <label for="user_name"> User Name</label>
                    <input type="text" name="user_name" class="form-control" value="<?php echo  $getRow['user_name']; ?>" >                
                </div>
                <div class="form-group">
                    <label for="role"> User Role</label>
                    <select name="role" id="" class="form-control" value="<?php echo $getRow['role'];?>">
                     
                    <?php 
                    if($getRow["role"]==1){
                        echo " <option value='1' selected> Admin </option>";
                        echo " <option value='0' > Modarator </option>";
                    }else{
                        echo " <option value='1'> Admin </option>";
                        echo " <option value='0' selected> Modarator </option>";
                    }
                    
                    ?>
                    
                    
                     
                    </select>               
                </div>
                
                <input type="submit" name="submit" value="Update" class="btn btn-info">

            
            
            
            </form>
        <?php }}
 ?>
        </div>
    </div>

</div>
</div>


<?php include_once "include/footer.php";?>