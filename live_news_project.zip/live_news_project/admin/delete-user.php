<?php 
require_once "include/config.php";
?>

<?php 
 
$delteID= $_GET["id"];
$deleteQuery="DELETE FROM users WHERE id= '$delteID'";
$runDeleteQuery= mysqli_query($connection, $deleteQuery);

if($runDeleteQuery){
    header("location:users.php?deleted");
}else{
    echo "Data deleted failed";

}

mysqli_close($connection);

?>




