<?php 
require_once "include/config.php";
include_once "include/header.php";
// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}



?>
<!-- Class- 46 -->

<div class="container">
<div class="user-content">
   <div class="row">
    <div class="col-md-10">
         <h1 class="admin-heading"> All Posts </h1>
    
    </div>
    <div class="col-md-2">
        <a href="add_post.php" class="add-new btn btn-info"> Add post</a>
    </div>

   </div>

<div class="col-md-12">

<?php 
if(isset($_GET["inserted"])){
    echo "<font color='green'> Post insert sucessfull. </font>";
}
if(isset($_GET["updated"])){
    echo  "<font color='green'> Post update sucessfull. </font>";
}

if(isset($_GET["deleted"])){
    echo  "<font color='green'> Post deleted sucessfull. </font>";
}

if(isset($_GET["deletedFail"])){
    echo  "<font color='red'> Post deleted Failed. </font>";
}
$limit= 5;
if(isset($_GET["page"])){
    $page_number= $_GET["page"];
}else{
    $page_number= 1; 
}

$offset= ($page_number - 1) * $limit;


//DESC LIMIT {$offset}, {$limit} 
//post.post_id, post.title, post.description, post.post_date, category.category_name, users.user_name
if($_SESSION["user_role"] == '1'){
    $postQuery= "SELECT  post.post_id, post.title, post.description, post.category, post.post_img, post.post_date, category.category_id, category.category_name, users.user_name FROM post 
    LEFT JOIN category ON post.category=category.category_id
    LEFT JOIN users ON post.author=users.id
    ORDER BY post.post_id DESC LIMIT {$offset}, {$limit}";
//DESC LIMIT {$offset}, {$limit}
 }elseif($_SESSION["user_role"]== '0'){ 
     $postQuery= "SELECT post.post_id, post.title, post.description, post.category, post.post_img, post.post_date, category.category_id, category.category_name, users.user_name  FROM post 
     LEFT JOIN category ON post.category=category.category_id
     LEFT JOIN users ON post.author=users.id
     WHERE post.author ={$_SESSION['id']}
     ORDER BY post.post_id DESC LIMIT {$offset}, {$limit}";
 }


$runPostQuery= mysqli_query($connection, $postQuery) or die("Select query failed.");

$countPost= mysqli_num_rows($runPostQuery);
if($countPost > 0){
    
?>
     <table class="content-table table-striped table-bordered ">
        <thead class="head-dark">
            <tr class="text-uppercase font-weight-bold ">
                <td> SL. NO </td>
                <td> Images </td>
                <td>title </td>
                <td> Category </td>
                <td>Date </td>
                <td>Author</td>
                <td>edit</td>
                <td> delete</td>

            </tr>        
        </thead>

       <tbody>
  <?php 
  $serial_number= 1;
   while($getRow= mysqli_fetch_assoc($runPostQuery)){
   
  ?>
        <tr>
        <td> <?php echo $serial_number++; ?></td>
        <td> <img width="50px" height="50px" class="rounded-circle" src="uploads/<?php echo $getRow["post_img"] ;?>" alt="Post images"> </td>
        <td> <?php echo $getRow["title"] ;?></td>
        <td> <?php echo $getRow["category_name"]; ?> </td>
        <td> <?php echo $getRow["post_date"]; ?> </td>
        <td> <?php echo  $getRow["user_name"]; ?> </td>
        <td class="edit"> <a href="update_post.php?id=<?php echo  $getRow["post_id"]; ?>"> <i class="fas fa-edit"></i> </a> </td>
        <td class="delete"> <a onclick="return confirm('Are you Sure??')" href="delete_post.php?id=<?php echo  $getRow["post_id"]; ?>&catId=<?php echo $getRow["category"]?> "> <i class="fa fa-trash-o"></i> </a> </td> 


        </tr>
<?php     }?>
        </tbody>
   <?php     }?>
    </table>
                 
                
    <div class="pagination">
 <?php 


$query= "SELECT * FROM post ";
$run= mysqli_query($connection, $query) or die("pagination query failed");
 $count= mysqli_num_rows($run);

if($count){
    $total_page= ceil($count/$limit);
    echo "<ul class='pagination admin-pagination m-auto justify-content-center py-5'>";
   if($page_number>1){
    echo '<li><a href="post.php?page='.($page_number-1).'"> Prev </a></li>';
    //  echo "<li> <a href='post.php?page='($page_number - 1)' '> Prev </a> </li>";

   }


for($i=1; $i<=$total_page; $i++){
  
    if($i==$page_number){
        $active= "active";
    }else{
        $active="";
    }
    echo '<li class=".$active." > <a href="post.php?page='.$i.'"> '.$i.' </a></li>';
   // echo '<li class="$active" > <a href="post.php?page= $i"> $i </a> </li>';
}

if($total_page > $page_number){
echo '<li><a href="post.php?page='.($page_number+1).'"> Next </a></li>';
//echo  "<li> <a href='post.php?page='$page_number + 1 ' '> Next </a> </li>";
}
echo "</ul>";
}

 ?>
       
    </div>
            
   
</div>
</div>
</div>




<?php include_once "include/footer.php";?>