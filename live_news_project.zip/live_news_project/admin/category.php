<?php 
require_once "include/config.php";
include_once "include/header.php";
// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}
if($_SESSION["user_role"]== '0'){
    header ("location:post.php");
}

?>

<div class="container">
<div class="user-content">
   <div class="row">
    <div class="col-md-10">
         <h1 class="admin-heading"> All Catagories </h1>
    
    </div>
    <div class="col-md-2">
        <a href="add_category.php" class="add-new btn btn-info"> Add Category</a>
    </div>

   </div>

<div class="col-md-12">

<?php

$query= "SELECT * FROM category ORDER BY category_id DESC";
$runQuery= mysqli_query($connection, $query);
$count= mysqli_num_rows($runQuery);

if($count > 0){


    if(isset($_GET["deleted"])){
        echo " <font color='green'>Category Deleted. </font> ";
    }

    if(isset($_GET["inserted"])){
        echo "Category insert success!!";
    }
?>


<!-- Table starts here -->
     <table class="table table-striped table-bordered content-table ">
        <thead class="thead-light">
            <tr class="text-uppercase font-weight-bold ">
                <td> SL. NO </td>
                <td> Category Name </td>
                <td>No of Post </td>
                <td>edit</td>
                <td> delete</td>

            </tr>        
        </thead>

        <tbody>
<?php 
$serial=1;
while($getRow= mysqli_fetch_assoc($runQuery)){
 
?>
      
  
        <tr>
        <td> <?php echo $serial++;?> </td>
        <td> <?php echo $getRow["category_name"];?></td>
        <td> <?php echo $getRow["post"];?> </td>
       
        
        <td class="edit"> <a href="update_category.php?id=<?php echo  $getRow["category_id"]; ?>"> <i class="fas fa-edit"></i> </a> </td>
        <td class="delete"> <a onclick="return confirm('Are you Sure??')" href="delete_category.php?id=<?php echo  $getRow["category_id"]; ?>"> <i class="fa fa-trash-o"></i> </a> </td> 


        </tr>
<?php } ?>      
        </tbody>
<?php } ?>
    </table>
                 
                
    
            
   
</div>
</div>

</div>





<?php include_once "include/footer.php";?>