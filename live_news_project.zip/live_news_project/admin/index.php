<?php 
require_once "include/config.php";
include "include/header.php";


if(isset($_SESSION["user_name"])){
    header ("location:post.php");
}

?>

<div class="container">
 <div class="login-container">  

    <div class="login-img text-center">
        <img width="150px" src="images/logo.png" alt="logo">
    </div>
    <div class="form-content">




    <form action="<?php $_SERVER['PHP_SELF'];?>" method="post">
        <div class="form-group">
            <label for="username">Username</label> 
            <input type="text" name="user_name" placeholder="User Name">
        </div>
        <div class="form-group">
            <label for="password">Password</label> 
            <input type="text" name="user_pwd" placeholder="Password">
        </div>
        <input type="submit" name="login" value="Login" class="btn btn-primary">


    </form>
    <?php 
if(isset($_GET["wrongInfo"])){
    echo "<font color='red'>Username or password does not match</font>";
    
}

if(isset($_POST["login"])){
    $user_name= mysqli_real_escape_string($connection, $_POST["user_name"]);
    $user_pwd= md5($_POST["user_pwd"]);;
// SELECT `id`, `first_name`, `last_name`, `user_name`, `user_email`, `user_pwd`, `role`, `signup_date` FROM `users` WHERE user_name='kawsar' AND user_pwd= '1234';
    $loginQuery="SELECT id, user_name, user_pwd, role FROM users WHERE
  user_name='{$user_name}' AND user_pwd= '{$user_pwd}'";


    $runLoginQuery= mysqli_query($connection, $loginQuery) or die("Query Faild");

     $count= mysqli_num_rows($runLoginQuery);
     if($count>0){
         while($row= mysqli_fetch_assoc($runLoginQuery)){
            
             $_SESSION['id']= $row["id"];
             $_SESSION["user_name"]= $row["user_name"];
             $_SESSION["user_role"]= $row["role"];
             header ("location:post.php");
           setcookie("PSSDMDNESW", "$user_name", time()+(86400*365));
            

          
         }         
         
     }else{
        header ("location:index.php?wrongInfo");
        
     }
  
}

?>

    </div>
    </div>
  </div>






<?php 
include_once "include/footer.php";
?>