<?php 
require_once "include/config.php";
include_once "include/header.php";

// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}

if($_SESSION["user_role"]== '0'){
    header ("location:post.php");
}

?>
<div class="container">
<div class="category-content">
    <div class="row">
        <div class="col-md-12">
            <div class="add_catagory_heading">
                <h1>Add Category</h1>

            </div>
            <div class="form_content">


 <?php 
 if(isset($_POST["submit"])){
     $category_name= mysqli_real_escape_string($connection, $_POST["category_name"]);

     $selectcategory= "SELECT category_name FROM category WHERE category_name= '{$category_name}' ";
     $runSelectcategory= mysqli_query($connection, $selectcategory) or die("Query Faild.");
     $countCategory= mysqli_num_rows($runSelectcategory);
     
     if($countCategory > 0){ 
         echo "Category already exists";
     }else{
         $insertCategory= "INSERT INTO category (category_name) VALUES ('$category_name')";
         $runInserCategory= mysqli_query($connection, $insertCategory) or die("Insert Query Failed.");
         if($runInserCategory){
             header ("location: category.php?inserted");
         }

     }
 }         
    
 
?>
                <!-- Form Start here -->
            <form action="<?php $_SERVER['PHP_SELF'];?>" method="POST" autocomplete="off">
                <div class="form-group">
                    <label for="Category Name"> Category Name </label>
                    <input type="text" name="category_name" class="form-control">
                
                </div>
                                   
                    <input type="submit" name="submit" value="Add" class="btn btn-info">
                
                         
            </form>

            </div>
        
        </div>
    
    </div>


</div>
</div>



<?php include_once "include/footer.php";?>
