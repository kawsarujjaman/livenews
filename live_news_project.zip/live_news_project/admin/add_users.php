<?php 
require_once "include/config.php";
include_once "include/header.php";

// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}

// Session 
if($_SESSION["user_role"]== '0'){
    header ("location: post.php");
}



?>

<div class="container">
<div class="admin-content">
    <div class="row">
        <div class="col-md-12">
            <h1 class=" admin-heading"> Add Users</h1>

        </div>

        <div class="col-md-offset-3 col-md-6 m-auto bg-light">


        <!-- Form starts here -->
        <?php
        if(isset($_POST["submit"])){
            $fname= mysqli_real_escape_string($connection, $_POST["fname"]);
            $lname= mysqli_real_escape_string($connection, $_POST["lname"]);
            $user_name= mysqli_real_escape_string($connection, $_POST["user_name"]);
            $user_email= mysqli_real_escape_string($connection, $_POST["user_email"]);
            $user_pwd= md5($_POST["user_pwd"]);
            $role= mysqli_real_escape_string($connection, $_POST["role"]);


            // Email varification
            
            $mailQuery= "SELECT user_email FROM users WHERE user_email='$user_email'";
            $runMailQuery= mysqli_query($connection, $mailQuery) or die("Query Failed.");
            $mailCount= mysqli_num_rows($runMailQuery);
           
            // username varification
            $query= "SELECT user_name FROM users WHERE user_name='$user_name'";
            $runQuery= mysqli_query($connection, $query) or die("Query Failed.");

            $counT= mysqli_num_rows($runQuery);
            if($counT>0){
                echo "Username already Exists";
            }elseif($mailCount>0){
                echo "<br>";
                echo "Emaill Address already Exists";
            } else{
                $insertQuery= "INSERT INTO users (first_name, last_name, user_name, user_email, user_pwd, role) VALUE ('$fname', '$lname', '$user_name', '$user_email', '$user_pwd', '$role')";
                $runInsertQuery= mysqli_query($connection, $insertQuery) or die("Query Failed.");

                
              if($runInsertQuery){
                header("location:users.php?addedUser");
              }else{
                echo "Add user failed";

              }
            }
            }
        



        
        ?>

            <form action="<?php $_SERVER['PHP_SELF'];?> " method="post" autocomplete="off">
                <div class="form-group">
                    <label for="fname"> First Name</label>
                    <input type="text" name="fname" class="form-control" placeholder="First Name" required>                
                </div>
                <div class="form-group">
                    <label for="lname"> Last Name</label>
                    <input type="text" name="lname" class="form-control" placeholder="Last Name" required>                
                </div>
                <div class="form-group">
                    <label for="user_name"> User Name</label>
                    <input type="text" name="user_name" class="form-control" placeholder="User Name" required>                
                </div>
                <div class="form-group">
                    <label for="user_email">  User Email</label>
                    <input type="text" name="user_email" class="form-control" placeholder="User  Email" required>                
                </div>
                <div class="form-group">
                    <label for="password"> Password </label>
                    <input type="password" name="user_pwd" class="form-control" placeholder="Password" required>                
                </div>
                <div class="form-group">
                    <label for="role"> User Role</label>
                    <select name="role" id="" class="form-control">
                        <option value="1"> Admin </option>
                        <option value="0"> Modarator </option>

                    </select>               
                </div>
                <input type="submit" name="submit" value="Add" class="btn btn-info">

            
            
            
            </form>
        
        </div>
    </div>

</div>
</div>




<?php 
include_once "include/footer.php";
?>