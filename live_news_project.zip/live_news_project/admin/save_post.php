<?php require_once "include/config.php";
session_start();

$errors= array();
    $imgFile=  $_FILES["post_img"];
    $img_name= $imgFile["name"];
    $img_size= $imgFile["size"];
    $img_tmp= $imgFile["tmp_name"];
    $img_type= $imgFile["type"];

    $file_ext= end(explode('.',$img_name));
    $extentions= array("jpeg","JPEG", "jpg", "JPG", "png", "PNG");

    if(in_array($file_ext, $extentions)==false){
        $errors[]="<font color='red'> This extension file not allowed, please choose JPEG, JPG, PNG file.</font>";
    }
    if($img_size > 2097152){
        $errors[]="<font color='red'>File size must be 2 MB or Lower. </font> "; 
    }

    $new_imgName= time()."-".basename($img_name);
    $target= "uploads/".$new_imgName;
   


 if(empty($errors)==true){
        move_uploaded_file($img_tmp, $target);
    }else{
        print_r($errors);
        die();
    }
    
$post_title= mysqli_real_escape_string($connection, $_POST["post_title"]);
$post_desc= mysqli_real_escape_string($connection, $_POST["post_desc"]);
$post_cat= mysqli_real_escape_string($connection, $_POST["post_cate"]);
$date= date("d M, Y");
$author= $_SESSION["id"];

//INSERT INTO `post`(`post_id`, `title`, `description`, `category`, `post_date`, `author`, `post_img`)

$insertQuery= "INSERT INTO post (title, description, category, post_date, author, post_img) 
VALUES ('{$post_title}', '{$post_desc}', '{$post_cat}', '$date', '{$author}','{$new_imgName}' );";
$insertQuery.="UPDATE category SET category.post= category.post + 1 WHERE category.category_id= '{$post_cat}' ";

$runInsertQuery= mysqli_multi_query($connection, $insertQuery) or die("Insert query failed.");

if($runInsertQuery){
   header("location:post.php?inserted");
}else{
    echo "<div class='alert alert-danger '> Post update failed. </div>";
}



?>
