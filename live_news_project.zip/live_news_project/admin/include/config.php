<?php

$connection= mysqli_connect("localhost", "root", "", "live_news_project") or die(" <h3> Establish database connection failed </h3> ".mysqli_error());



?>