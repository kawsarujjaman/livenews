<?php
session_start();
session_regenerate_id();
$error = '';
// If we logout through sesseion than comment in last line

// Cookie
// if(!isset($_COOKIE["PSSDMDNESW"])){
//     header ("location:index.php");
// }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live News Project using: BOOTSTRAP CSS PHP JAVA</title>
    <!-- Style sheet link -->
    <link rel="stylesheet" href="style.css">
    <!-- Fontawesome link -->
    <script src="https://kit.fontawesome.com/71f2e6313b.js" crossorigin="anonymous"></script>
    <!-- Bootstrap cdn link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>

    </style>

</head>
<body>

 <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="../index.php"> <img width="50px" src="images/logo.png" alt="Logo"> </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav m-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="../index">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    
                </ul>
        </div>
       
       <div >
       <?php    /*
       if(isset($_COOKIE["PSSDMDNESW"])){
           echo $_COOKIE["PSSDMDNESW"].", ";
       }*/
       if($_SESSION["user_name"]?? ""){
        echo ($_SESSION["user_name"].",  ");
       }

       if($_SESSION["user_name"]?? ""){
        echo '<a  href="logout.php"> Logout </a>';
       }
       ?>
      
       
       </div>     
        
        </nav>
<!-- Nav ends here -->


        <div class="secondary_menu bg-light my-5 py-3 text-center">
        <?php 
        /*
       if(isset($_COOKIE["PSSDMDNESW"])){
        echo ' ';
       }
       */
       ?>
       <?PHP  if ($_SESSION["user_name"]?? ""){ ?>
      
    <a href="post"> POST </a>
       <!-- Session start for Category, Users -->
      <?php
     
      if ($_SESSION["user_role"]?? ""=="1"){ ?>

      <?php    
       /*
       if(isset($_COOKIE["PSSDMDNESW"])){
        echo ' <a href="category.php"> CATEGORY </a>';
       }
       ?>


      <?php 
       if(isset($_COOKIE["PSSDMDNESW"])){
        echo ' <a href="users.php"> USERS </a>';
       }
    */
       ?>   
 
        <a href="category"> CATEGORY </a>  
        <a href="users"> USERS </a>
      <?php }} ?>     
                
</div>
</div>
  




