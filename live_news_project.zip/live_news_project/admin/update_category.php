<?php 
require_once "include/config.php";
include_once "include/header.php";
// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}
if($_SESSION["user_role"]== '0'){
    header ("location:post.php");
}



if(isset($_POST["category_btn"])){
    $category_id= $_POST["id"];
    $category_name= $_POST["category_name"];

    $updateCategory= "UPDATE category SET category_name= '$category_name' WHERE category_id= '$category_id' ";
    $runUpdateCategory= mysqli_query($connection, $updateCategory) or die("Update Query Failed.");

    if($runUpdateCategory){
        header("location:category.php");
    }

}

?>

<div class="container">
<div class="update_category">
    <div class="row">
        <div class="col-md-12">
            <div class="category_heading">
                <h1>Update Category </h1>
            </div>
            <div class="col-md-offset-3 col-md-6">
               <div class="form_content">

<?php 

$category_id= $_REQUEST["id"];

$selectCat= "SELECT * FROM category WHERE category_id= '{$category_id}' ";
$runSelectCat= mysqli_query($connection, $selectCat) or die("Select category failed.");

$countCat=mysqli_num_rows($runSelectCat);
if($countCat > 0){
    while($getRow= mysqli_fetch_assoc($runSelectCat)){
        
?>

                <form action="<?php $_SERVER['PHP_SELF'] ;?>" method="post">
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $getRow["category_id"];?>">
                    </div>
                    <div class="form-group">
                        <label for="category name"> Category Name </label>
                        <input type="text" name="category_name" value="<?php echo $getRow["category_name"];?>">
                    </div>
                    
                        <input type="submit" name="category_btn" value="Update" class="btn btn-info">
                    
                    </form>

<?php     }
} ?>
            </div>
               </div> 
               
        </div>

    </div>

</div>
</div>




<?php include_once "include/footer.php";?>
