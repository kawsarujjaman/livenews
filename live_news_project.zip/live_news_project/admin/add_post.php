<?php 
require_once "include/config.php";
include_once "include/header.php";

// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}

?>

<div class="container">
<div class="category-content">
    <div class="row">
        <div class="col-md-12">
            <div class="add_catagory_heading">
                <h1>Add Category</h1>

            </div>
            <div class="form_content">
            
            <!-- Form Starts here -->
                <form action="save_post.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="post_title"> Title </label>
                        <input type="text" name="post_title" class="form-control" >
                    
                    </div>
                
                    <div class="form-group">
                        <label for="post_desc"> Description </label>
                        
                        <textarea name="post_desc" id="" style="resize: none;" rows="3" class="form-control"></textarea>
                    
                    </div>
                    <div class="form-group">
                        <label for="post_cat"> Category </label>
                        <select name="post_cate" id="">

                           <option disabled selected >Select Category</option>

<?php
$catQuery= "SELECT * FROM category";
$runCatQuery= mysqli_query($connection, $catQuery) or die("category query failed. ");

if(mysqli_num_rows($runCatQuery) > 0){
    while($row= mysqli_fetch_assoc($runCatQuery)){
        
        echo "<option value='{$row['category_id']}' > {$row['category_name']} </option>";
    }
}

?>
                        </select>
                    
                    </div>

                    <div class="form-group">
                        <label for="post_img"> Select Image </label>
                        <input type="file" name="post_img" class="form-control" >
                    
                    </div>

                    <input type="submit" value="Save" name="submit" class="btn btn-info">

                
                </form>
            </div>
        </div>
    </div>
</div>
</div>

<?php include_once "include/footer.php";?>