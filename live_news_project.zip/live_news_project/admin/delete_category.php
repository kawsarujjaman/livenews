<?php 
require_once "include/config.php";
include_once "include/header.php";
// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}
if($_SESSION["user_role"]== '0'){
    header ("location:post.php");
}

$category_id= $_GET["id"];
$deleteCat= "DELETE FROM category WHERE category_id= '$category_id'";
$runDeleteCat= mysqli_query($connection, $deleteCat) or die("Delete Catagory query faield.");

if($runDeleteCat){
    header ("location: category.php?deleted");
}else{
    echo "Catagory deleted failed.";
}


?>






<?php include_once "include/footer.php";?>
