<?php
session_start();
unset($_SESSION["user_name"]);
unset($_SESSION["user_role"]);

session_destroy();
header("location:index.php");


if(isset($_COOKIE["PSSDMDNESW"])){
    setcookie("PSSDMDNESW", "$user_name", time()-(86400*365));
    header("location:index.php");
}


die();
?>