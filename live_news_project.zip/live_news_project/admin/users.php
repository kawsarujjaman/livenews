<?php 

require_once "include/config.php";
include_once "include/header.php";


// Cookie
 if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}

    if($_SESSION["user_role"]== '0'){
        header ("location: post.php");
    }
    

?>

<div class="container">
<div class="user-content">
   <div class="row">
    <div class="col-md-10">
         <h1 class="admin-heading"> All Users </h1>
    
    </div>
    <div class="col-md-2">
        <a href="add_users.php" class="add-new btn btn-info"> Add Users</a>
    </div>

   </div>

<div class="col-md-12">

    <?php 

if(isset($_REQUEST["addedUser"])){
    echo "<center><font color='green' > Add user successfull </font></center>" ;
}
if(isset($_GET["deleted"])){
    echo "<center><font color='green' > User Deteted Sucessfull </font></center>" ;

}elseif(isset($_GET["updated"])){
    echo "<center><font color='green' > User Updated.....  </font></center>" ;
}

//  pagination starts here 
$limit=5;
if(isset($_GET["page"])){
    $page_number= $_GET["page"];
}else{
    $page_number= 1; //Default page number =1
}

 $offset= ($page_number - 1) * $limit;
//  pagination ends here 

    $selectQuery= "SELECT * FROM users ORDER BY id DESC LIMIT {$offset},{$limit} ";
    $runSelectQuery= mysqli_query($connection, $selectQuery);
    $counT= mysqli_num_rows($runSelectQuery) or die("Query Failed.");
    if($counT>0){
  
        
    ?>

    <table class="content-table">
        <thead class="head-dark">
            <tr class="text-uppercase font-weight-bold ">
                <td> SL. NO </td>
                <td>Full Name </td>
                <td>User name</td>
                <td>User Email</td>
                <td>Role</td>
                <td>edit</td>
                <td> delete</td>

            </tr>        
        </thead>

       <tbody>
    <?php 
    while($getRow= mysqli_fetch_assoc($runSelectQuery)){
          
 
      ?>

        <tr>
        <td><?php echo  $getRow["id"]; ?> </td>
        <td><?php echo  $getRow["first_name"]." ".$getRow["last_name"]; ?> </td>
        <td> <?php echo  $getRow["user_name"]; ?> </td>
        <td> <?php echo  $getRow["user_email"]; ?> </td>
        <td>
             <?php 
             
             if($getRow["role"]==1){
                 echo "Admin";
             }else{
                 echo "Moderator";
             }
              ?> 
    
    
    </td>
        <td class="edit"> <a href="update-user?id=<?php echo  $getRow["id"]; ?>"> <i class="fas fa-edit"></i> </a> </td>
        <td class="delete"> <a onclick="return confirm('Are you Sure??')" href="delete-user?id=<?php echo  $getRow["id"]; ?>"> <i class="fa fa-trash-o"></i> </a> </td> 


        </tr>
<?php } ?>
        </tbody>
    <?php } ?>
    </table>
             
<?php 

$paginationQuery= "SELECT * FROM users";
$runPagination= mysqli_query($connection, $paginationQuery) or die("Pagination Query failed.");
$countPagination= mysqli_num_rows($runPagination);
if($countPagination){
     $total_records= $countPagination;
     $total_page= ceil($total_records/$limit);

     echo "<ul class='pagination admin-pagination justify-content-center mt-3'> ";
     if($page_number>1){
        echo '<li><a href="users.php?page='.($page_number-1).'"> Prev </a></li>';
    }

     for($i=1; $i<=$total_page; $i++){

         if($i == $page_number){
             $active= "active";
        }else{
             $active="";
         }
             echo '<li class=".$active." > <a href="users.php?page='.$i.'"> '.$i.' </a></li>';
        }


         if($total_page > $page_number){
             echo '<li><a href="users.php?page='.($page_number+1).'"> Next </a></li>';
         }
         echo "</ul>";
    

}

?>
            
   
</div>
</div>
</div>


<?php include_once "include/footer.php";?>