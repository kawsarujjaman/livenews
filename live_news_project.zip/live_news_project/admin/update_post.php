<?php 
require_once "include/config.php";
include_once "include/header.php";
// Cookie
if(!isset($_COOKIE["PSSDMDNESW"])){
    header ("location:index.php");
}

// Session 
if(!$_SESSION["user_name"]){
    header ("location: index.php");
}


?>

<div class="container">
<div class="update_category">
    <div class="row">
        <div class="col-md-12">
            <div class="category_heading">
                <h1>Update Post </h1>
            </div>
            <div class="col-md-offset-3 col-md-6">
               <div class="form_content">

                <!-- Form Starts here -->
<?php

$get_id= $_GET["id"];


$postQuery=  "SELECT post.post_id, post.title, post.description, post.post_img, post.category, category.category_id, category.category_name, users.user_name  FROM post
--  LEFT JOIN category ON post.category=category_name
LEFT JOIN category ON post.category=category_id 
LEFT JOIN users ON post.author=users.id
WHERE post.post_id ={$get_id}";

$runPost_query= mysqli_query($connection, $postQuery) or die("Update Post Query Failed");

$countPost_query= mysqli_num_rows($runPost_query);
if($countPost_query > 0){
while( $getRow= mysqli_fetch_assoc($runPost_query)){
    

?>
                <form action="update_post_core.php" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <div class="form-group">
                        <input type="hidden" name="post_id" value="<?php echo $getRow['post_id'];?>">
                    </div>
                    <div class="form-group">
                        <label for="post_title"> Title </label>
                        <input type="text" name="post_title" value="<?php echo $getRow['title'];?>" class="form-control" >
                    
                    </div>
                
                    <div class="form-group">
                        <label for="post_desc"> Description </label>
                        
                        <textarea name="post_desc" id="" style="resize: none;" rows="3" value="<?php  echo $getRow['description'];?>" class="form-control"><?php  echo $getRow['description'];?> </textarea>
                    
                    </div>
                    
                    <div class="form-group">
                        <label for="post_cat"> Category </label>
                        <select name="post_cate" id="">
                        <option disabled selected > Select Category </option>
<?php

$catQuery= "SELECT * FROM category";
$runCat_query= mysqli_query($connection, $catQuery) or die("Category query failed. ");
$countCat= mysqli_num_rows($runCat_query);
if($countCat > 0){
    while($row= mysqli_fetch_assoc($runCat_query)){

        if($getRow["category"] == $row["category_id"]){
            $selected= "selected";
        }else{
            $selected="";
        }
        echo "<option {$selected} value='{$row['category_id']}' > {$row['category_name']} </option>";
    }
}

?>

                     </select>
                    <input type="hidden" name="old_categoty" value="<?php echo $getRow["category"]?>" >
                    </div>

                    <div class="form-group">
                        <label for="post_img"> Post Image </label>
                        <input type="file" name="new_img" class="form-control" >
                        <img height="150px" src="uploads/<?php echo $getRow['post_img'];?>" alt="">
                        <input type="hidden" name="old_img" value="<?php echo $getRow['post_img'];?>" >

                    
                    </div>

                    <input type="submit" value="Update" name="submit" class="btn btn-info">
                    
                    </form>

<?php }
    }else{
        echo "Result Not Found";
    }

    ?>
          </div>
               </div> 
               
        </div>

    </div>

</div>
</div>





<?php include_once "include/footer.php";?>
