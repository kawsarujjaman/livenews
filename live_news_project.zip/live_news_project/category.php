<?php
include "include/header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
body {
    background: white  !important;
}
    </style>







<main>
    <div class="container">
        <div class="container_wrapper">

            <div class="row ">             
                <!-- Post section starts here -->
                <div class="col-md-8 ">
                    <div class="category_heading">

<?php 
require_once "include/config.php";

if(isset($_GET["category_ID"])){
    $category_id = $_GET["category_ID"];

             $query= "SELECT * FROM category WHERE category_id= {$category_id} ";   
            $runQuery= mysqli_query($connection, $query) or die("Category name show query failed");
            $newRow= mysqli_fetch_assoc($runQuery);
                           
?>  
<h2> <?php echo strtoupper($newRow['category_name']);?> </h2>
                    </div> 
    
                    
<?php 
require_once "include/config.php";

$category_id = $_GET["category_ID"];

$limit= 5;
if(isset($_GET["page"])){
    $page_number= $_GET["page"];
}else{
    $page_number= 1; 
}

$offset= ($page_number - 1) * $limit;

    $postQuery= "SELECT  post.post_id, post.title, post.description, post.category, post.post_img, post.post_date,  category.category_id, category.category_name, users.id, users.user_name FROM post 
    LEFT JOIN category ON post.category=category.category_id
    LEFT JOIN users ON post.author=users.id WHERE post.category={$category_id}
    ORDER BY post.post_id DESC LIMIT {$offset}, {$limit}";


$runPostQuery= mysqli_query($connection, $postQuery) or die("Select query failed.");

$countPost= mysqli_num_rows($runPostQuery);
if($countPost > 0){
    while($getRow= mysqli_fetch_assoc($runPostQuery)){
        
?>
                
                    <div class="post_container">
                        <div class="row">
                            <div class="col-md-4">                            
                                <a href="single.php?id=<?php echo $getRow["post_id"]?>"> <img class="post_img" src="admin/uploads/<?php echo $getRow["post_img"]?>" alt="Post Image"> </a>
                            </div>

                            <div class="col-md-8">                            
                                <div class="post_content">
                                    <h4><a href="single.php?id=<?php echo $getRow["post_id"]?>"> <?php echo $getRow["title"]?> </a></h4>
                                    <p class="post_info">
                                        <span>
                                            <i class="fa fa-tags"></i>
                                            <a href="category.php?category_ID=<?php echo $getRow["category_id"]?>"><?php echo $getRow["category_name"]?></a> 
                                        </span>
                                        <span>
                                        <i class="fa fa-user"></i>
                                        <a href="author.php?author_ID=<?php echo $getRow['id']?>"> <?php echo $getRow["user_name"];?> </a>
                                        </span>
                                        <span>
                                        <i class="fa fa-calendar"></i>
                                            <a href=""> <?php echo $getRow["post_date"]?></a>
                                        </span> 
                                    </p>
                                    <p> <?php echo substr($getRow["description"],0,145)."..."?> </p>
                                    <p class="readmorelink"><a href="single.php?id=<?php echo $getRow["post_id"]?>">Read More</a></p>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                      <!-- Post section Ends here -->  
 <?php     }
       }else{
           echo "No record found.";
       }}
?>
                <div class="pagination">
 <?php  


$query= "SELECT * FROM post WHERE post.category={$category_id}";
$run= mysqli_query($connection, $query) or die("pagination query failed");
 $count= mysqli_num_rows($run);

if($count){
    $total_page= ceil($count/$limit);
    echo "<ul class='pagination admin-pagination m-auto justify-content-center py-5'>";
   if($page_number>1){
    echo '<li><a href="category.php?category_ID='.$category_id.'&page='.($page_number-1).'"> Prev </a></li>';
    //  echo "<li> <a href='post.php?page='($page_number - 1)' '> Prev </a> </li>";

   }


for($i=1; $i<=$total_page; $i++){
  
    if($i==$page_number){
        $active= "active";
    }else{
        $active="";
    }
    echo '<li class=".$active." > <a href="category.php?category_ID='.$category_id.'&page='.$i.'"> '.$i.' </a></li>';
   // echo '<li class="$active" > <a href="post.php?page= $i"> $i </a> </li>';
}

if($total_page > $page_number){
echo '<li><a href="category.php?category_ID='.$category_id.'&page='.($page_number+1).'"> Next </a></li>';
//echo  "<li> <a href='post.php?page='$page_number + 1 ' '> Next </a> </li>";
}
echo "</ul>";
}

 ?>
       
    </div>
    <!-- Pagination ends here -->                
          </div>
              
          
             
<?php
include "sidebar.php";
?>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
                
                </div>
                
        </div>
            <!-- Row ends -->


        </div>
        
        
    </div>
</main>









<?php
include "footer.php";
?>














<!-- Container ends here -->
 </div> 


<!-- jQuery, Popper.js  -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>