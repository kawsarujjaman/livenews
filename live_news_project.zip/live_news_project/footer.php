<div class="container-fluid p-0 m-0">
<footer class="footer bg-dark text-light text-center p-3 mt-5">
    <div class="footer-container">

        <p> Copyright &copy; Kawsarujjaman || All right reserved </p>    
    </div>


</footer>
</div>