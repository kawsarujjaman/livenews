<?php
include "include/header.php";
require_once "include/config.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
body {
    background: white  !important;
}
    </style>



<div class="container">
    <div class="container_wrapper">

        <div class="row ">             
                <!-- Post section starts here -->
            <div class="col-md-8 ">
                
      
                <div class="SinglePage_post_container">
<?php 
    $post_id= $_GET["id"];
    $postQuery= "SELECT  post.post_id, post.title, post.description, post.category, post.post_img, post.post_date, category.category_id, category.category_name, users.id, users.user_name FROM post 
    LEFT JOIN category ON post.category=category.category_id
    LEFT JOIN users ON post.author=users.id WHERE post.post_id= {$post_id}" ;


$runPostQuery= mysqli_query($connection, $postQuery) or die("Select query failed.");

$countPost= mysqli_num_rows($runPostQuery);
if($countPost > 0){
    while($getRow= mysqli_fetch_assoc($runPostQuery)){
        
?>

                    <div class="SinglePage_post_content">
                        <h4><a href="single.php"> <?php echo $getRow["title"] ?> </a> </h4>
                        <p class="post_info">
                            <span>
                                <i class="fa fa-tags"></i>
                                <a href="category.php?category_ID=<?php echo $getRow["category_id"]?>"><?php echo $getRow["category_name"]?></a> 
                            </span>
                            <span>
                                <i class="fa fa-user"></i>
                                <a href="author.php?author_ID=<?php echo $getRow['id']?>"> <?php echo $getRow["user_name"];?> </a>
                            </span>
                            <span>
                                <i class="fa fa-calendar"></i>
                                <a href=""> <?php echo $getRow["post_date"]?></a>
                            </span> 
                        </p>
                    </div>
                    <!-- SinglePage image starts here -->
                    <div class="singlePage_img mr-auto">
                        <img  src="admin/uploads/<?php echo $getRow["post_img"]?>" alt="Single Page image">
                    </div>
                    <!-- SinglePage paragraph starts here -->
                    <div class="singlePage_para">
                        <p><?php echo $getRow["description"]?></p>
                    </div>


<?php     
    }
    }else{
        echo "No record found.";
    }
?>
                    <!-- post_container ends here -->
                </div>

     
            </div>
            
            <?php
include "sidebar.php";
?>
               

        <!-- row ends here -->
    </div>
</div>


</div>
</div>
<?php
include "include/footer.php";

?>