 <!-- Sidebar starts here -->
                <div class="col-md-4 ">
                    <div class="sidebar">
                        <div class="searchBar">
                            <h4>Search</h4>
                            <!-- Form starts here -->
                            <form action="search.php" method="get">
                            <div class="searchItem">
                                <input type="text" name="search" placeholder="Search">
                                <input type="submit" class="" value="Search">
                            </div>
                            </form>
                            <!-- Form ends here -->

                        </div>
                        <hr>
                        <div class="sidebar_content">
                            <h4>RECENT POST</h4>

                            <div class="sidebar_item">
                            <div class="row">
                            <div class="col-md-4">                            
                                <img class="post_img" src="admin/uploads/1623773464-DSC_9205.JPG" alt="Post Image">
                            </div>

                            <div class="col-md-8">                            
                                <div class="post_content">
                                <h6><a href="#">What is java?</a></h6>
                                    <p class="post_info">
                                        <span>
                                            <i class="fa fa-tags"></i>
                                            <a href="">Java</a> 
                                        </span>
                                      
                                        <span>
                                        <i class="fa fa-calendar"></i>
                                            <a href="">July, 20 2021</a>
                                        </span>
                                    </p>
                                   
                                    <p class="readmorelink"><a href="#">Read More</a></p>
                                </div>
                            </div>
                        </div>

                        </div>
                        <hr>
                            <!-- Sidebar item ends here -->
                         
                            <div class="sidebar_item">
                            <div class="row">
                            <div class="col-md-4">                            
                                <img class="post_img" src="admin/uploads/1623773464-DSC_9205.JPG" alt="Post Image">
                            </div>

                            <div class="col-md-8">                            
                                <div class="post_content">
                                <h6><a href="#">What is java?</a></h6>
                                    <p class="post_info">
                                        <span>
                                            <i class="fa fa-tags"></i>
                                            <a href="">Java</a> 
                                        </span>
                                      
                                        <span>
                                        <i class="fa fa-calendar"></i>
                                            <a href="">July, 20 2021</a>
                                        </span>
                                    </p>
                                   
                                    <p class="readmorelink"><a href="#">Read More</a></p>
                                </div>
                            </div>
                        </div>

                        </div>
                        <hr>
                            <!-- Sidebar item ends here -->


                            <div class="sidebar_item">
                            <div class="row">
                            <div class="col-md-4">                            
                                <img class="post_img" src="admin/uploads/1623773464-DSC_9205.JPG" alt="Post Image">
                            </div>

                            <div class="col-md-8">                            
                                <div class="post_content">
                                <h6><a href="#">What is java?</a></h6>
                                    <p class="post_info">
                                        <span>
                                            <i class="fa fa-tags"></i>
                                            <a href="">Java</a> 
                                        </span>
                                      
                                        <span>
                                        <i class="fa fa-calendar"></i>
                                            <a href="">July, 20 2021</a>
                                        </span>
                                    </p>
                                   
                                    <p class="readmorelink"><a href="#">Read More</a></p>
                                </div>
                            </div>
                        </div>

                        </div>
                        <hr>
                            <!-- Sidebar item ends here -->


                    <div class="sidebar_item">
                        <div class="row">
                                <div class="col-md-4">                            
                                    <img class="post_img" src="admin/uploads/1623773464-DSC_9205.JPG" alt="Post Image">
                                </div>

                            <div class="col-md-8">                            
                                <div class="post_content">
                                    <h6><a href="#">What is java?</a></h6>
                                    <p class="post_info">
                                        <span>
                                            <i class="fa fa-tags"></i>
                                            <a href="">Java</a> 
                                        </span>
                                      
                                        <span>
                                        <i class="fa fa-calendar"></i>
                                            <a href="">July, 20 2021</a>
                                        </span>
                                    </p>
                                   
                                    <p class="readmorelink"><a href="#">Read More</a></p>
                                </div>
                                <!-- post_content ends here -->

                            </div>
                        </div>

                    </div>

                        <hr>
                            <!-- Sidebar item ends here -->
                    </div>
                </div>
                         